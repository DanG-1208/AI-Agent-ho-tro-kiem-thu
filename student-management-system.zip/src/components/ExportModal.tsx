import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Download, FileSpreadsheet, FileText, Check, CheckSquare, Square } from 'lucide-react';
import { useStudents } from '../context/StudentContext';
import { ExportFormat, Student } from '../types/student';

export const ExportModal: React.FC = () => {
  const {
    students,
    filteredStudents,
    selectedStudentIds,
    isExportModalOpen,
    setIsExportModalOpen,
    handleExport
  } = useStudents();

  const [format, setFormat] = useState<ExportFormat>('xlsx');
  const [scope, setScope] = useState<'all' | 'filtered' | 'selected'>(
    selectedStudentIds.length > 0 ? 'selected' : 'filtered'
  );
  const [fileName, setFileName] = useState('student_records_' + new Date().toISOString().slice(0, 10));

  const ALL_FIELDS: { key: keyof Student; label: string }[] = [
    { key: 'id', label: 'Student ID' },
    { key: 'fullName', label: 'Full Name' },
    { key: 'gender', label: 'Gender' },
    { key: 'dob', label: 'Date of Birth' },
    { key: 'email', label: 'Email Address' },
    { key: 'phone', label: 'Phone Number' },
    { key: 'gpa', label: 'GPA' },
    { key: 'department', label: 'Department' },
    { key: 'status', label: 'Status' },
    { key: 'enrollmentYear', label: 'Enrollment Year' }
  ];

  const [includedFields, setIncludedFields] = useState<(keyof Student)[]>([
    'id',
    'fullName',
    'gender',
    'dob',
    'email',
    'phone',
    'gpa',
    'department',
    'status'
  ]);

  if (!isExportModalOpen) return null;

  const toggleField = (fieldKey: keyof Student) => {
    setIncludedFields((prev) =>
      prev.includes(fieldKey) ? prev.filter((f) => f !== fieldKey) : [...prev, fieldKey]
    );
  };

  const toggleAllFields = () => {
    if (includedFields.length === ALL_FIELDS.length) {
      setIncludedFields(['id', 'fullName', 'email']);
    } else {
      setIncludedFields(ALL_FIELDS.map((f) => f.key));
    }
  };

  const getRecordCount = () => {
    if (scope === 'all') return students.length;
    if (scope === 'filtered') return filteredStudents.length;
    if (scope === 'selected') return selectedStudentIds.length;
    return 0;
  };

  const onExecuteExport = (e: React.FormEvent) => {
    e.preventDefault();
    handleExport({
      format,
      scope,
      includeFields: includedFields,
      fileName
    });
    setIsExportModalOpen(false);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6"
        >
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Export Student Data
                </h3>
                <p className="text-xs text-slate-400">
                  Generate Excel (.xlsx) or CSV (.csv) report file
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsExportModalOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={onExecuteExport} className="mt-4 space-y-4 text-xs">
            
            {/* Format Selector */}
            <div>
              <label className="block font-semibold text-slate-300 mb-2">Export File Format</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setFormat('xlsx')}
                  className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                    format === 'xlsx'
                      ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/50'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  <FileSpreadsheet className="w-6 h-6 text-emerald-400 shrink-0" />
                  <div className="text-left">
                    <div className="font-bold text-slate-100">Excel (.xlsx)</div>
                    <div className="text-[10px] text-slate-400">Microsoft Excel Spreadsheet</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setFormat('csv')}
                  className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                    format === 'csv'
                      ? 'bg-indigo-950/40 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500/50'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  <FileText className="w-6 h-6 text-indigo-400 shrink-0" />
                  <div className="text-left">
                    <div className="font-bold text-slate-100">CSV (.csv)</div>
                    <div className="text-[10px] text-slate-400">Comma-Separated Values</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Scope Selector */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">Record Scope</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setScope('filtered')}
                  className={`py-2 px-3 rounded-xl border font-medium text-center transition-colors ${
                    scope === 'filtered'
                      ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Filtered ({filteredStudents.length})
                </button>

                <button
                  type="button"
                  onClick={() => setScope('all')}
                  className={`py-2 px-3 rounded-xl border font-medium text-center transition-colors ${
                    scope === 'all'
                      ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  All ({students.length})
                </button>

                <button
                  type="button"
                  disabled={selectedStudentIds.length === 0}
                  onClick={() => setScope('selected')}
                  className={`py-2 px-3 rounded-xl border font-medium text-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${
                    scope === 'selected'
                      ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Selected ({selectedStudentIds.length})
                </button>
              </div>
            </div>

            {/* File Name */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">File Name</label>
              <input
                type="text"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-slate-100 font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Field Checklist */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-semibold text-slate-300">Included Columns</label>
                <button
                  type="button"
                  onClick={toggleAllFields}
                  className="text-[11px] text-indigo-400 hover:underline"
                >
                  Toggle All
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto p-2 bg-slate-950/60 rounded-xl border border-slate-800">
                {ALL_FIELDS.map((f) => {
                  const isChecked = includedFields.includes(f.key);
                  return (
                    <button
                      key={f.key}
                      type="button"
                      onClick={() => toggleField(f.key)}
                      className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-800 text-left transition-colors"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      ) : (
                        <Square className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                      )}
                      <span className={isChecked ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                        {f.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <span className="text-[11px] text-slate-400">
                Ready to export <strong className="text-white">{getRecordCount()}</strong> student record(s)
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsExportModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-xl font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={getRecordCount() === 0 || includedFields.length === 0}
                  className="px-4 py-1.5 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Report</span>
                </button>
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
