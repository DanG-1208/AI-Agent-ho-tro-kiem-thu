import React, { useState } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Edit2,
  Trash2,
  Eye,
  XCircle,
  ChevronLeft,
  ChevronRight,
  UserPlus,
  CheckSquare,
  Square,
  Sparkles,
  Download
} from 'lucide-react';
import { useStudents } from '../context/StudentContext';
import { Student } from '../types/student';
import { DEPARTMENTS } from '../data/mockStudents';

export const StudentTable: React.FC = () => {
  const {
    filteredStudents,
    filters,
    setFilters,
    clearFilters,
    selectedStudentIds,
    toggleSelectStudent,
    toggleSelectAll,
    setEditingStudent,
    setViewingStudent,
    setDeletingStudent,
    setIsAddModalOpen,
    setIsBulkDeleteOpen,
    setIsExportModalOpen
  } = useStudents();

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Filter drawer toggle for mobile/desktop
  const [showFiltersDrawer, setShowFiltersDrawer] = useState(false);

  // Sorting Handler
  const handleSort = (field: keyof Student) => {
    setFilters((prev) => ({
      ...prev,
      sortBy: field,
      sortOrder: prev.sortBy === field && prev.sortOrder === 'asc' ? 'desc' : 'asc'
    }));
  };

  // Pagination logic
  const totalItems = filteredStudents.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedStudents = filteredStudents.slice(startIndex, startIndex + itemsPerPage);

  const isAllSelected =
    filteredStudents.length > 0 && selectedStudentIds.length === filteredStudents.length;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
      
      {/* Search & Filter Controls Header */}
      <div className="p-4 sm:p-5 border-b border-slate-800 space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* FR-04 Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="student-search-input"
              type="text"
              value={filters.searchQuery}
              onChange={(e) => {
                setFilters((prev) => ({ ...prev, searchQuery: e.target.value }));
                setCurrentPage(1);
              }}
              placeholder="Search by Student ID, Name, or Email..."
              className="w-full pl-10 pr-10 py-2.5 bg-slate-800 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
            {filters.searchQuery && (
              <button
                onClick={() => setFilters((prev) => ({ ...prev, searchQuery: '' }))}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <XCircle className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Filter Controls & Batch Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowFiltersDrawer(!showFiltersDrawer)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
                filters.department || filters.gender || filters.status
                  ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/50'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters</span>
              {(filters.department || filters.gender || filters.status) && (
                <span className="w-2 h-2 rounded-full bg-indigo-400" />
              )}
            </button>

            {/* Batch Delete Action */}
            {selectedStudentIds.length > 0 && (
              <button
                onClick={() => setIsBulkDeleteOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-rose-600/20 text-rose-300 border border-rose-500/50 hover:bg-rose-600/30 transition-colors animate-pulse"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected ({selectedStudentIds.length})</span>
              </button>
            )}

            {/* Clear All Filters */}
            {(filters.searchQuery || filters.department || filters.gender || filters.status) && (
              <button
                onClick={() => {
                  clearFilters();
                  setCurrentPage(1);
                }}
                className="text-xs text-slate-400 hover:text-slate-200 underline px-2 py-1"
              >
                Reset filters
              </button>
            )}
          </div>
        </div>

        {/* Filter Drawer / Expanded Row */}
        {showFiltersDrawer && (
          <div className="pt-3 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 bg-slate-950/40 p-3 rounded-xl border border-slate-800">
            {/* Department Filter */}
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">Department</label>
              <select
                value={filters.department}
                onChange={(e) => {
                  setFilters((prev) => ({ ...prev, department: e.target.value }));
                  setCurrentPage(1);
                }}
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Departments</option>
                {DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            {/* Gender Filter */}
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">Gender</label>
              <select
                value={filters.gender}
                onChange={(e) => {
                  setFilters((prev) => ({ ...prev, gender: e.target.value }));
                  setCurrentPage(1);
                }}
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Genders</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => {
                  setFilters((prev) => ({ ...prev, status: e.target.value }));
                  setCurrentPage(1);
                }}
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Graduated">Graduated</option>
                <option value="On Leave">On Leave</option>
              </select>
            </div>

            {/* Clear button in drawer */}
            <div className="flex items-end">
              <button
                onClick={clearFilters}
                className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors"
              >
                Clear Filter Settings
              </button>
            </div>
          </div>
        )}
      </div>

      {/* View Student List Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 text-xs uppercase tracking-wider font-semibold">
              <th className="py-3 px-4 w-10 text-center">
                <button
                  onClick={toggleSelectAll}
                  className="text-slate-400 hover:text-white transition-colors"
                  aria-label="Select all students"
                >
                  {isAllSelected ? (
                    <CheckSquare className="w-4 h-4 text-indigo-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>
              </th>
              
              {/* Student ID Column Header */}
              <th
                onClick={() => handleSort('id')}
                className="py-3 px-4 cursor-pointer hover:text-slate-200 select-none"
              >
                <div className="flex items-center gap-1.5">
                  <span>Student ID</span>
                  {filters.sortBy === 'id' ? (
                    filters.sortOrder === 'asc' ? (
                      <ArrowUp className="w-3.5 h-3.5 text-indigo-400" />
                    ) : (
                      <ArrowDown className="w-3.5 h-3.5 text-indigo-400" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              {/* Full Name Column Header */}
              <th
                onClick={() => handleSort('fullName')}
                className="py-3 px-4 cursor-pointer hover:text-slate-200 select-none"
              >
                <div className="flex items-center gap-1.5">
                  <span>Full Name</span>
                  {filters.sortBy === 'fullName' ? (
                    filters.sortOrder === 'asc' ? (
                      <ArrowUp className="w-3.5 h-3.5 text-indigo-400" />
                    ) : (
                      <ArrowDown className="w-3.5 h-3.5 text-indigo-400" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              <th className="py-3 px-4">Gender</th>
              <th className="py-3 px-4">Email</th>

              {/* GPA Column Header */}
              <th
                onClick={() => handleSort('gpa')}
                className="py-3 px-4 cursor-pointer hover:text-slate-200 select-none text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>GPA</span>
                  {filters.sortBy === 'gpa' ? (
                    filters.sortOrder === 'asc' ? (
                      <ArrowUp className="w-3.5 h-3.5 text-indigo-400" />
                    ) : (
                      <ArrowDown className="w-3.5 h-3.5 text-indigo-400" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              <th className="py-3 px-4">Department</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-800/80 text-sm">
            {paginatedStudents.length > 0 ? (
              paginatedStudents.map((student) => {
                const isSelected = selectedStudentIds.includes(student.id);

                return (
                  <tr
                    key={student.id}
                    className={`hover:bg-slate-800/50 transition-colors ${
                      isSelected ? 'bg-indigo-950/20' : ''
                    }`}
                  >
                    {/* Row Checkbox */}
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleSelectStudent(student.id)}
                        className="text-slate-400 hover:text-white transition-colors"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-indigo-400" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                    </td>

                    {/* Student ID */}
                    <td className="py-3.5 px-4 font-mono font-medium text-indigo-300 text-xs">
                      {student.id}
                    </td>

                    {/* Full Name */}
                    <td className="py-3.5 px-4 font-semibold text-slate-100">
                      {student.fullName}
                    </td>

                    {/* Gender */}
                    <td className="py-3.5 px-4 text-slate-300 text-xs">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-md ${
                          student.gender === 'Female'
                            ? 'bg-fuchsia-500/10 text-fuchsia-300'
                            : student.gender === 'Male'
                            ? 'bg-blue-500/10 text-blue-300'
                            : 'bg-slate-700/50 text-slate-300'
                        }`}
                      >
                        {student.gender}
                      </span>
                    </td>

                    {/* Email */}
                    <td className="py-3.5 px-4 text-slate-300 text-xs">
                      {student.email}
                    </td>

                    {/* GPA */}
                    <td className="py-3.5 px-4 text-right">
                      <span
                        className={`font-bold text-xs px-2 py-1 rounded-lg ${
                          student.gpa >= 3.5
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : student.gpa >= 3.0
                            ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                            : student.gpa >= 2.5
                            ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {student.gpa.toFixed(2)}
                      </span>
                    </td>

                    {/* Department */}
                    <td className="py-3.5 px-4 text-slate-300 text-xs truncate max-w-[150px]">
                      {student.department}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4 text-xs">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-medium ${
                          student.status === 'Active'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : student.status === 'Graduated'
                            ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                            : student.status === 'On Leave'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-slate-700/50 text-slate-400 border border-slate-600/50'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            student.status === 'Active'
                              ? 'bg-emerald-400'
                              : student.status === 'Graduated'
                              ? 'bg-indigo-400'
                              : student.status === 'On Leave'
                              ? 'bg-amber-400'
                              : 'bg-slate-400'
                          }`}
                        />
                        {student.status}
                      </span>
                    </td>

                    {/* Actions (View, Edit, Delete) */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {/* View Details */}
                        <button
                          onClick={() => setViewingStudent(student)}
                          className="p-1.5 text-slate-400 hover:text-sky-300 hover:bg-slate-800 rounded-lg transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Edit */}
                        <button
                          onClick={() => setEditingStudent(student)}
                          className="p-1.5 text-slate-400 hover:text-indigo-300 hover:bg-slate-800 rounded-lg transition-colors"
                          title="Edit Student Information"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        {/* Delete */}
                        <button
                          onClick={() => setDeletingStudent(student)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Delete Student Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={9} className="py-12 text-center text-slate-400">
                  <div className="max-w-xs mx-auto flex flex-col items-center">
                    <Search className="w-10 h-10 text-slate-600 mb-2" />
                    <p className="font-semibold text-slate-300 text-sm">No student records found</p>
                    <p className="text-xs text-slate-400 mt-1 mb-4">
                      Try adjusting your search criteria or add a new student record.
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={clearFilters}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs transition-colors"
                      >
                        Reset Search
                      </button>
                      <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors"
                      >
                        + Add Student
                      </button>
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination & Footer controls */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
        <div>
          Showing{' '}
          <span className="font-semibold text-slate-200">
            {totalItems === 0 ? 0 : startIndex + 1}
          </span>{' '}
          to{' '}
          <span className="font-semibold text-slate-200">
            {Math.min(startIndex + itemsPerPage, totalItems)}
          </span>{' '}
          of <span className="font-semibold text-slate-200">{totalItems}</span> students
        </div>

        <div className="flex items-center gap-3">
          {/* Items per page selector */}
          <div className="flex items-center gap-1.5">
            <span>Rows:</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="bg-slate-800 border border-slate-700 rounded-md px-2 py-1 text-slate-200 focus:outline-none"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
          </div>

          {/* Pagination Buttons */}
          <div className="flex items-center gap-1">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-700 transition-colors"
              aria-label="Previous Page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-medium text-slate-200">
              {currentPage} / {totalPages}
            </span>
            <button
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-700 transition-colors"
              aria-label="Next Page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
