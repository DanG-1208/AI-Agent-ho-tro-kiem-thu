import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  User,
  Mail,
  Phone,
  Calendar,
  Award,
  BookOpen,
  CheckCircle2,
  Clock,
  Edit2,
  Trash2
} from 'lucide-react';
import { useStudents } from '../context/StudentContext';

export const StudentDetailModal: React.FC = () => {
  const { viewingStudent, setViewingStudent, setEditingStudent, setDeletingStudent } =
    useStudents();

  if (!viewingStudent) return null;

  const handleEdit = () => {
    const studentToEdit = viewingStudent;
    setViewingStudent(null);
    setEditingStudent(studentToEdit);
  };

  const handleDelete = () => {
    const studentToDelete = viewingStudent;
    setViewingStudent(null);
    setDeletingStudent(studentToDelete);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden"
        >
          {/* Top Banner */}
          <div className="h-24 bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 relative p-4 flex items-start justify-between">
            <span className="px-2.5 py-1 bg-slate-900/60 backdrop-blur-md rounded-lg text-xs font-mono text-indigo-300 font-semibold border border-indigo-500/30">
              {viewingStudent.id}
            </span>
            <button
              onClick={() => setViewingStudent(null)}
              className="p-1.5 text-slate-300 hover:text-white bg-slate-900/60 hover:bg-slate-900 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Profile Content */}
          <div className="px-6 pb-6 pt-0 relative">
            {/* Avatar Badge */}
            <div className="-mt-10 mb-4 flex items-end justify-between">
              <div className="w-20 h-20 rounded-2xl bg-slate-800 border-4 border-slate-900 flex items-center justify-center shadow-xl text-indigo-400 font-bold text-2xl">
                {viewingStudent.fullName.charAt(0)}
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  viewingStudent.status === 'Active'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : viewingStudent.status === 'Graduated'
                    ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                }`}
              >
                {viewingStudent.status}
              </span>
            </div>

            {/* Name & Major */}
            <div>
              <h3 className="text-xl font-bold text-slate-100">{viewingStudent.fullName}</h3>
              <p className="text-xs text-indigo-400 font-medium flex items-center gap-1 mt-0.5">
                <BookOpen className="w-3.5 h-3.5" />
                {viewingStudent.department}
              </p>
            </div>

            {/* Metric Card */}
            <div className="grid grid-cols-2 gap-3 my-5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <div>
                <p className="text-[11px] font-medium text-slate-400">Cumulative GPA</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xl font-bold text-indigo-300">
                    {viewingStudent.gpa.toFixed(2)}
                  </span>
                  <span className="text-[10px] text-slate-400">/ 4.00</span>
                </div>
              </div>

              <div>
                <p className="text-[11px] font-medium text-slate-400">Academic Standing</p>
                <p className="text-xs font-semibold text-emerald-400 mt-1 flex items-center gap-1">
                  <Award className="w-3.5 h-3.5" />
                  {viewingStudent.gpa >= 3.5
                    ? 'First Class Honors'
                    : viewingStudent.gpa >= 3.0
                    ? 'Good Standing'
                    : 'Satisfactory'}
                </p>
              </div>
            </div>

            {/* Information Grid */}
            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-3 text-slate-300">
                <User className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-400">Gender:</span>
                <span className="font-medium text-slate-200">{viewingStudent.gender}</span>
              </div>

              <div className="flex items-center gap-3 text-slate-300">
                <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-400">Date of Birth:</span>
                <span className="font-medium text-slate-200">{viewingStudent.dob}</span>
              </div>

              <div className="flex items-center gap-3 text-slate-300">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-400">Email:</span>
                <span className="font-medium text-slate-200 select-all">{viewingStudent.email}</span>
              </div>

              <div className="flex items-center gap-3 text-slate-300">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-400">Phone:</span>
                <span className="font-medium text-slate-200">{viewingStudent.phone}</span>
              </div>

              <div className="flex items-center gap-3 text-slate-300">
                <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-400">Enrollment Year:</span>
                <span className="font-medium text-slate-200">{viewingStudent.enrollmentYear}</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-5 mt-5 border-t border-slate-800">
              <button
                onClick={handleDelete}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-rose-400 bg-rose-950/30 hover:bg-rose-950/60 border border-rose-800/50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleEdit}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors shadow-md shadow-indigo-600/30"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
