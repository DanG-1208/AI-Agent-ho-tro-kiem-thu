import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, FileText, CheckCircle2, Workflow, Zap, Layers, TestTube2, CheckSquare } from 'lucide-react';
import { useStudents } from '../context/StudentContext';

export const RequirementDocView: React.FC = () => {
  const { isDocModalOpen, setIsDocModalOpen } = useStudents();
  const [activeTab, setActiveTab] = useState<'srs' | 'qa'>('qa');

  if (!isDocModalOpen) return null;

  const qaTestCases = [
    // Add Student
    {
      id: 'TC-ADD-001',
      feature: 'Add Student',
      scenario: 'Successful Student Creation with Valid Input Data',
      steps: [
        '1. Click "Add Student" button.',
        '2. Fill in unique ID (e.g., STU9999), Name ("Alex Rivera"), Gender, DoB, Email ("alex.rivera@univ.edu"), Phone, Dept, and GPA ("3.85").',
        '3. Click "Save Student".'
      ],
      expected: 'Validation passes, new record is created, toast notification appears, modal closes, and STU9999 is listed in table.',
      priority: 'High'
    },
    {
      id: 'TC-ADD-002',
      feature: 'Add Student',
      scenario: 'Duplicate Student ID Rejection',
      steps: [
        '1. Click "Add Student" button.',
        '2. Enter an existing Student ID (e.g., STU1001) and fill other fields.',
        '3. Click "Save Student".'
      ],
      expected: 'System displays validation error "Student ID already exists in the system", blocks form submission, and keeps modal open.',
      priority: 'High'
    },
    {
      id: 'TC-ADD-003',
      feature: 'Add Student',
      scenario: 'Mandatory Field Validation',
      steps: [
        '1. Click "Add Student" button.',
        '2. Leave mandatory fields (Student ID, Name, Email) blank.',
        '3. Click "Save Student".'
      ],
      expected: 'Form submission blocked; inline error messages highlight required missing fields.',
      priority: 'High'
    },
    {
      id: 'TC-ADD-004',
      feature: 'Add Student',
      scenario: 'Invalid Email Format Validation',
      steps: [
        '1. Click "Add Student".',
        '2. Fill fields but enter "invalid-email-string" for Email.',
        '3. Click "Save Student".'
      ],
      expected: 'System displays "Please enter a valid email address" error.',
      priority: 'Medium'
    },
    {
      id: 'TC-ADD-005',
      feature: 'Add Student',
      scenario: 'GPA Boundary Range Validation (0.00 - 4.00)',
      steps: [
        '1. Open Add Student form.',
        '2. Enter GPA as "4.50" or "-0.5".',
        '3. Click "Save Student".'
      ],
      expected: 'System rejects out-of-bounds GPA values with error "GPA must be between 0.00 and 4.00".',
      priority: 'Medium'
    },

    // Edit Student
    {
      id: 'TC-EDIT-001',
      feature: 'Edit Student',
      scenario: 'Successful Update of Student Details',
      steps: [
        '1. Click Edit button (pencil icon) for student STU1001.',
        '2. Modify Full Name to "Sarah Connor Updated" and GPA to "3.95".',
        '3. Click "Save Changes".'
      ],
      expected: 'Student record updates in state, success toast notification displays, and updated values appear in the table.',
      priority: 'High'
    },
    {
      id: 'TC-EDIT-002',
      feature: 'Edit Student',
      scenario: 'Primary Key Immutability (Disabled Student ID)',
      steps: [
        '1. Click Edit on any student record.',
        '2. Inspect the Student ID input field.'
      ],
      expected: 'Student ID input field is disabled/read-only to preserve record identity integrity.',
      priority: 'High'
    },
    {
      id: 'TC-EDIT-003',
      feature: 'Edit Student',
      scenario: 'Cancel Edit Operation',
      steps: [
        '1. Click Edit on STU1002.',
        '2. Modify Phone number.',
        '3. Click "Cancel" or Close (X).'
      ],
      expected: 'Modal closes without persisting changes; original data remains unmodified.',
      priority: 'Medium'
    },

    // Delete Student
    {
      id: 'TC-DEL-001',
      feature: 'Delete Student',
      scenario: 'Single Student Record Deletion with Confirmation',
      steps: [
        '1. Click Delete (trash icon) for student STU1005.',
        '2. Verify student details in modal dialog.',
        '3. Click "Confirm Delete".'
      ],
      expected: 'Student STU1005 is removed from database/state, table updates, and success toast displays.',
      priority: 'High'
    },
    {
      id: 'TC-DEL-002',
      feature: 'Delete Student',
      scenario: 'Cancel Single Record Deletion',
      steps: [
        '1. Click Delete for STU1006.',
        '2. Click "Cancel" in confirmation modal.'
      ],
      expected: 'Modal closes and student record remains intact in the table.',
      priority: 'Medium'
    },
    {
      id: 'TC-DEL-003',
      feature: 'Delete Student',
      scenario: 'Bulk / Batch Student Deletion',
      steps: [
        '1. Check selection boxes for STU1007 and STU1008.',
        '2. Click top action button "Delete Selected (2)".',
        '3. Click "Confirm Batch Delete".'
      ],
      expected: 'All selected students are deleted concurrently, selection state resets, and toast notification confirms batch deletion.',
      priority: 'High'
    },

    // Search Student
    {
      id: 'TC-SCH-001',
      feature: 'Search Student',
      scenario: 'Search by Exact and Partial Student ID',
      steps: [
        '1. Type "STU1003" in the search input box.'
      ],
      expected: 'Table filters instantaneously (< 20ms) showing only STU1003.',
      priority: 'High'
    },
    {
      id: 'TC-SCH-002',
      feature: 'Search Student',
      scenario: 'Search by Full Name (Case-Insensitive)',
      steps: [
        '1. Type "sarah" in the search bar.'
      ],
      expected: 'Table displays matching student records regardless of uppercase/lowercase formatting.',
      priority: 'High'
    },
    {
      id: 'TC-SCH-003',
      feature: 'Search Student',
      scenario: 'Multi-Criteria Filter Combination',
      steps: [
        '1. Select Department = "Computer Science".',
        '2. Select Status = "Active".',
        '3. Type "John" in search input.'
      ],
      expected: 'Table displays only student records satisfying all active search criteria simultaneously.',
      priority: 'Medium'
    },
    {
      id: 'TC-SCH-004',
      feature: 'Search Student',
      scenario: 'Zero Search Results Handling',
      steps: [
        '1. Type non-existent query "XYZ99999" in search bar.'
      ],
      expected: 'Table presents an empty state message "No students found matching your search" with a quick clear option.',
      priority: 'Low'
    },

    // Export Excel
    {
      id: 'TC-EXP-001',
      feature: 'Export Excel',
      scenario: 'Export Complete Student Directory to Excel (.xlsx)',
      steps: [
        '1. Click "Export" in top navigation bar.',
        '2. Select Format = "Excel Workbook (.xlsx)".',
        '3. Scope = "All Students".',
        '4. Click "Download Report".'
      ],
      expected: 'System compiles student records into standard .xlsx binary format and initiates automatic browser download.',
      priority: 'High'
    },
    {
      id: 'TC-EXP-002',
      feature: 'Export Excel',
      scenario: 'Export Filtered Student Subset to Excel (.xlsx)',
      steps: [
        '1. Apply filter Department = "Business".',
        '2. Open Export Modal.',
        '3. Select Scope = "Filtered Students".',
        '4. Click "Download Report".'
      ],
      expected: 'Excel workbook downloads containing exclusively Business department student rows.',
      priority: 'Medium'
    },

    // Export CSV
    {
      id: 'TC-EXP-003',
      feature: 'Export CSV',
      scenario: 'Export Student Records to Standard CSV (.csv)',
      steps: [
        '1. Click "Export".',
        '2. Select Format = "CSV (.csv)".',
        '3. Scope = "All Students".',
        '4. Click "Download Report".'
      ],
      expected: 'Browser downloads a valid UTF-8 formatted .csv file with comma separation and accurate column header row.',
      priority: 'High'
    },
    {
      id: 'TC-EXP-004',
      feature: 'Export CSV',
      scenario: 'CSV Special Characters Escaping (Commas/Quotes)',
      steps: [
        '1. Ensure student record contains commas in address field.',
        '2. Export CSV report.',
        '3. Open downloaded CSV file.'
      ],
      expected: 'Address string is correctly escaped in double quotes in the CSV output to prevent column column breaking.',
      priority: 'Medium'
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80 shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                <TestTube2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Student Management System Specification & QA Test Suite
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  <button
                    onClick={() => setActiveTab('qa')}
                    className={`px-2.5 py-0.5 rounded-md text-xs font-semibold transition-colors ${
                      activeTab === 'qa'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    QA Test Cases Suite ({qaTestCases.length})
                  </button>
                  <button
                    onClick={() => setActiveTab('srs')}
                    className={`px-2.5 py-0.5 rounded-md text-xs font-semibold transition-colors ${
                      activeTab === 'srs'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    SRS Requirements Doc
                  </button>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsDocModalOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Document Content */}
          <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-300 leading-relaxed">
            
            {activeTab === 'qa' ? (
              <div className="space-y-6">
                <div className="p-4 rounded-xl bg-indigo-950/40 border border-indigo-800/60 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <CheckSquare className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm text-indigo-200">QA Test Suite Active</h4>
                      <p className="mt-1 text-slate-300 text-xs">
                        Comprehensive test scenarios for Add, Edit, Delete, Search, and Export (Excel & CSV) features.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Test Cases Table */}
                <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-slate-400">
                        <th className="py-3 px-3.5 font-bold w-28">Test ID</th>
                        <th className="py-3 px-3.5 font-bold w-32">Feature</th>
                        <th className="py-3 px-3.5 font-bold">Test Scenario</th>
                        <th className="py-3 px-3.5 font-bold">Test Steps</th>
                        <th className="py-3 px-3.5 font-bold">Expected Result</th>
                        <th className="py-3 px-3.5 font-bold text-center w-20">Priority</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {qaTestCases.map((tc) => (
                        <tr key={tc.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="py-3 px-3.5 font-mono font-bold text-indigo-400 align-top">
                            {tc.id}
                          </td>
                          <td className="py-3 px-3.5 font-semibold text-slate-200 align-top">
                            <span className="inline-block px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[11px]">
                              {tc.feature}
                            </span>
                          </td>
                          <td className="py-3 px-3.5 font-medium text-slate-100 align-top">
                            {tc.scenario}
                          </td>
                          <td className="py-3 px-3.5 text-slate-300 align-top space-y-1">
                            {tc.steps.map((s, idx) => (
                              <div key={idx}>{s}</div>
                            ))}
                          </td>
                          <td className="py-3 px-3.5 text-emerald-300 align-top font-sans">
                            {tc.expected}
                          </td>
                          <td className="py-3 px-3.5 text-center align-top">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                tc.priority === 'High'
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                  : tc.priority === 'Medium'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                              }`}
                            >
                              {tc.priority}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                {/* Status Callout */}
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-sm text-emerald-200">System Fully Compliant & Verified</h4>
                    <p className="mt-1 text-slate-300 text-xs">
                      All functional requirements, non-functional performance goals, and user stories are fully implemented in code and active in this application.
                    </p>
                  </div>
                </div>

                {/* Section 1: Functional Requirements */}
                <section>
                  <h4 className="text-sm font-bold text-indigo-400 uppercase tracking-wider mb-3 flex items-center gap-2 border-b border-slate-800 pb-2">
                    <Layers className="w-4 h-4" /> 1. Functional Requirements
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Add Student</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Administrator adds a new student. Fields: Student ID, Full Name, Gender, Date of Birth, Email, Phone Number, GPA.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Edit Student</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Modify existing student records. Fields: Full Name, Gender, Date of Birth, Email, Phone Number, GPA, Status.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Delete Student</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Permanently remove single or multiple student records with confirmation dialog.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Search Student</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Search students in real-time by Student ID or Name, plus filters for department, gender, and status.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>View Student List</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Display all student records in table format with sorting, pagination, and multi-selection.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Data Validation</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Validate required Student ID (non-empty & unique), valid email format, GPA between 0.0 and 4.0.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60 md:col-span-2">
                      <div className="font-bold text-slate-100 text-xs flex items-center justify-between">
                        <span>Export Student Data</span>
                        <span className="text-[10px] text-emerald-400 font-mono">IMPLEMENTED</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Generate and download reports in Excel (.xlsx) and CSV (.csv) formats with dynamic column selection.
                      </p>
                    </div>
                  </div>
                </section>

                {/* Section 2: Non-functional Requirements */}
                <section>
                  <h4 className="text-sm font-bold text-sky-400 uppercase tracking-wider mb-3 flex items-center gap-2 border-b border-slate-800 pb-2">
                    <Zap className="w-4 h-4" /> 2. Non-functional Requirements (NFR)
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-01 Performance</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Instant client-side search (&lt; 20ms response time)</p>
                    </div>
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-02 Usability</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Clean, accessible UI with Tailwind & Lucide icons</p>
                    </div>
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-03 Reliability</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Data saved in localStorage with fallback dataset</p>
                    </div>
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-04 Security</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Admin authenticated authorization state simulation</p>
                    </div>
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-05 Maintainability</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Modular TypeScript React components & clean Context</p>
                    </div>
                    <div className="p-2.5 bg-slate-800/40 rounded-lg border border-slate-700/50">
                      <div className="font-semibold text-slate-200">NFR-06 Compatibility</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">Works on Chrome, Edge, Firefox, and Safari</p>
                    </div>
                  </div>
                </section>

                {/* Section 3: Use Case Summary Table */}
                <section>
                  <h4 className="text-sm font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center gap-2 border-b border-slate-800 pb-2">
                    <Workflow className="w-4 h-4" /> 3. Use Case Summary & Workflow Architecture
                  </h4>
                  <div className="overflow-x-auto rounded-xl border border-slate-800">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400">
                        <tr>
                          <th className="p-2.5">Use Case</th>
                          <th className="p-2.5">Actor</th>
                          <th className="p-2.5">Description</th>
                          <th className="p-2.5 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">Add Student</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Create a new student with full validation</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">Edit Student</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Update student information</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">Delete Student</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Remove student records permanently</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">Search Student</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Find student records by ID or Name</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">View Student List</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Display all students in responsive table</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-200">Export Data</td>
                          <td className="p-2.5 text-slate-400">Admin</td>
                          <td className="p-2.5">Generate Excel (.xlsx) and CSV reports</td>
                          <td className="p-2.5 text-right text-emerald-400 font-semibold">Active</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>
            )}

          </div>

          {/* Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end shrink-0">
            <button
              onClick={() => setIsDocModalOpen(false)}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors"
            >
              Close Window
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

