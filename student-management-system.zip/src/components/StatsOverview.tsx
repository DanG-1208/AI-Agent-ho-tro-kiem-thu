import React, { useState } from 'react';
import { Users, Award, TrendingUp, CheckCircle, ChevronDown, ChevronUp, UserCheck, PieChart } from 'lucide-react';
import { useStudents } from '../context/StudentContext';

export const StatsOverview: React.FC = () => {
  const { stats } = useStudents();
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 sm:p-5 mb-6 backdrop-blur-sm shadow-xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-100">Analytics & Key Metrics</h2>
            <p className="text-xs text-slate-400">Overview of student performance and demographic distribution</p>
          </div>
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700"
        >
          {isExpanded ? (
            <>
              <span>Collapse</span> <ChevronUp className="w-3.5 h-3.5" />
            </>
          ) : (
            <>
              <span>Expand Analytics</span> <ChevronDown className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-2">
          {/* Card 1: Total Students */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-400">Total Registered</p>
              <h3 className="text-2xl font-bold text-slate-100 mt-1">{stats.total}</h3>
              <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                <UserCheck className="w-3 h-3" /> {stats.activeCount} Active Status
              </p>
            </div>
            <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl">
              <Users className="w-6 h-6" />
            </div>
          </div>

          {/* Card 2: Average GPA */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-400">Average GPA</p>
              <div className="flex items-baseline gap-2 mt-1">
                <h3 className="text-2xl font-bold text-indigo-400">{stats.averageGpa.toFixed(2)}</h3>
                <span className="text-xs text-slate-400">/ 4.00</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Across all departments
              </p>
            </div>
            <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>

          {/* Card 3: Honor Roll (GPA >= 3.5) */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-400">Honor Roll (GPA ≥ 3.5)</p>
              <h3 className="text-2xl font-bold text-amber-400 mt-1">{stats.honorStudents}</h3>
              <p className="text-[11px] text-amber-400/90 mt-1">
                {stats.total > 0 ? Math.round((stats.honorStudents / stats.total) * 100) : 0}% of cohort
              </p>
            </div>
            <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl">
              <Award className="w-6 h-6" />
            </div>
          </div>

          {/* Card 4: GPA Distribution Breakdown */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
            <p className="text-xs font-medium text-slate-400 mb-2">GPA Grade Distribution</p>
            <div className="space-y-1.5 text-xs">
              <div>
                <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
                  <span>3.5 - 4.0 (Honor)</span>
                  <span className="font-semibold text-emerald-400">{stats.gpaRanges.excelente}</span>
                </div>
                <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-400 h-full rounded-full"
                    style={{
                      width: `${stats.total > 0 ? (stats.gpaRanges.excelente / stats.total) * 100 : 0}%`
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
                  <span>3.0 - 3.49 (Good)</span>
                  <span className="font-semibold text-indigo-400">{stats.gpaRanges.bueno}</span>
                </div>
                <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-400 h-full rounded-full"
                    style={{
                      width: `${stats.total > 0 ? (stats.gpaRanges.bueno / stats.total) * 100 : 0}%`
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
                  <span>Below 3.0</span>
                  <span className="font-semibold text-amber-400">
                    {stats.gpaRanges.promedio + stats.gpaRanges.bajo}
                  </span>
                </div>
                <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full rounded-full"
                    style={{
                      width: `${
                        stats.total > 0
                          ? ((stats.gpaRanges.promedio + stats.gpaRanges.bajo) / stats.total) * 100
                          : 0
                      }%`
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
