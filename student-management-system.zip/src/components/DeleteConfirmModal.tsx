import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { useStudents } from '../context/StudentContext';

export const DeleteConfirmModal: React.FC = () => {
  const {
    deletingStudent,
    setDeletingStudent,
    deleteStudent,
    isBulkDeleteOpen,
    setIsBulkDeleteOpen,
    selectedStudentIds,
    deleteBulkStudents
  } = useStudents();

  if (!deletingStudent && !isBulkDeleteOpen) return null;

  const isBulk = isBulkDeleteOpen;

  const handleConfirm = () => {
    if (isBulk) {
      deleteBulkStudents(selectedStudentIds);
      setIsBulkDeleteOpen(false);
    } else if (deletingStudent) {
      deleteStudent(deletingStudent.id);
      setDeletingStudent(null);
    }
  };

  const handleCancel = () => {
    setDeletingStudent(null);
    setIsBulkDeleteOpen(false);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6"
        >
          <button
            onClick={handleCancel}
            className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3.5 mb-4">
            <div className="p-3 bg-rose-500/10 text-rose-400 rounded-2xl border border-rose-500/20">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                {isBulk ? 'Confirm Batch Deletion' : 'Delete Student Record'}
              </h3>
              <p className="text-xs text-rose-400/90 font-medium">This operation cannot be undone</p>
            </div>
          </div>

          <div className="my-4 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-300">
            {isBulk ? (
              <p>
                You are about to permanently remove{' '}
                <span className="font-bold text-white">{selectedStudentIds.length}</span> student
                record(s) from the system.
              </p>
            ) : deletingStudent ? (
              <div className="space-y-1">
                <p>Are you sure you want to permanently delete this student record?</p>
                <div className="mt-2 pt-2 border-t border-slate-700/60 font-mono text-indigo-300">
                  <span className="font-bold">{deletingStudent.fullName}</span> ({deletingStudent.id})
                </div>
              </div>
            ) : null}
          </div>

          <div className="flex items-center justify-end gap-3 mt-6">
            <button
              onClick={handleCancel}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 transition-colors shadow-lg shadow-rose-600/30 flex items-center gap-1.5"
            >
              <Trash2 className="w-4 h-4" />
              <span>Confirm Delete</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
