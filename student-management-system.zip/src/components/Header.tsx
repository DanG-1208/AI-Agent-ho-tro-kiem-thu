import React from 'react';
import {
  GraduationCap,
  Plus,
  Download,
  FileText,
  RotateCcw,
  ShieldCheck,
  Search,
  Sparkles
} from 'lucide-react';
import { useStudents } from '../context/StudentContext';

export const Header: React.FC = () => {
  const {
    setIsAddModalOpen,
    setIsExportModalOpen,
    setIsDocModalOpen,
    resetToSampleData,
    filters,
    setFilters
  } = useStudents();

  return (
    <header id="sms-main-header" className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Application Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center shadow-md shadow-indigo-500/20 ring-1 ring-white/20">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg text-slate-100 tracking-tight leading-none">
                  Student Management System
                </h1>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <ShieldCheck className="w-3 h-3" /> Admin Auth
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block mt-0.5">
                BA Software Requirements Compliance
              </p>
            </div>
          </div>

          {/* Search Bar in Header (Quick Access) */}
          <div className="hidden md:flex items-center flex-1 max-w-xs mx-4">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search Student ID or Name..."
                value={filters.searchQuery}
                onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-800/80 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            {/* View Requirements Doc */}
            <button
              id="btn-view-requirements"
              onClick={() => setIsDocModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white border border-slate-700 transition-colors shadow-sm"
              title="View Business Analyst Requirements & Use Case Diagrams"
            >
              <FileText className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden lg:inline">Requirements Doc</span>
            </button>

            {/* Reset Data */}
            <button
              id="btn-reset-data"
              onClick={() => {
                if (window.confirm('Reset database to initial sample student records?')) {
                  resetToSampleData();
                }
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors"
              title="Reset Sample Data"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Reset</span>
            </button>

            {/* Export Data Button (FR-07) */}
            <button
              id="btn-export-data"
              onClick={() => setIsExportModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-100 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Export</span>
            </button>

            {/* Add Student Button (FR-01) */}
            <button
              id="btn-add-student-header"
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors shadow-md shadow-indigo-600/20 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Add Student</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
