import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, AlertCircle, Save, CheckCircle, UserPlus, UserCheck } from 'lucide-react';
import { useStudents } from '../context/StudentContext';
import { StudentFormData, ValidationError } from '../types/student';
import { DEPARTMENTS } from '../data/mockStudents';
import { generateNextStudentId } from '../utils/validation';

export const StudentFormModal: React.FC = () => {
  const {
    students,
    isAddModalOpen,
    setIsAddModalOpen,
    editingStudent,
    setEditingStudent,
    addStudent,
    updateStudent
  } = useStudents();

  const isEditing = Boolean(editingStudent);
  const isOpen = isAddModalOpen || isEditing;

  const initialFormState: StudentFormData = {
    id: '',
    fullName: '',
    gender: 'Male',
    dob: '2002-01-01',
    email: '',
    phone: '',
    gpa: '3.50',
    department: DEPARTMENTS[0],
    status: 'Active',
    enrollmentYear: new Date().getFullYear().toString()
  };

  const [formData, setFormData] = useState<StudentFormData>(initialFormState);
  const [errors, setErrors] = useState<ValidationError[]>([]);

  useEffect(() => {
    if (editingStudent) {
      setFormData({
        id: editingStudent.id,
        fullName: editingStudent.fullName,
        gender: editingStudent.gender,
        dob: editingStudent.dob,
        email: editingStudent.email,
        phone: editingStudent.phone,
        gpa: editingStudent.gpa.toString(),
        department: editingStudent.department,
        status: editingStudent.status,
        enrollmentYear: editingStudent.enrollmentYear.toString()
      });
      setErrors([]);
    } else if (isAddModalOpen) {
      const nextId = generateNextStudentId(students);
      setFormData({
        ...initialFormState,
        id: nextId
      });
      setErrors([]);
    }
  }, [editingStudent, isAddModalOpen, students]);

  const handleClose = () => {
    setIsAddModalOpen(false);
    setEditingStudent(null);
    setErrors([]);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear field-level error on edit
    setErrors((prev) => prev.filter((err) => err.field !== name));
  };

  const handleGenerateId = () => {
    const nextId = generateNextStudentId(students);
    setFormData((prev) => ({ ...prev, id: nextId }));
    setErrors((prev) => prev.filter((err) => err.field !== 'id'));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing) {
      const res = updateStudent(formData);
      if (res.success) {
        handleClose();
      } else if (res.errors) {
        setErrors(res.errors);
      }
    } else {
      const res = addStudent(formData);
      if (res.success) {
        handleClose();
      } else if (res.errors) {
        setErrors(res.errors);
      }
    }
  };

  const getFieldError = (field: keyof StudentFormData) => {
    return errors.find((e) => e.field === field)?.message;
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8"
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
                {isEditing ? <UserCheck className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  {isEditing ? 'Edit Student Record' : 'Add New Student Record'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isEditing
                    ? 'Update profile parameters with real-time validation'
                    : 'Enter details for the new student record'}
                </p>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Validation Banner */}
          {errors.length > 0 && (
            <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold block mb-0.5">Validation Errors Detected:</span>
                <ul className="list-disc list-inside space-y-0.5 opacity-90">
                  {errors.map((err, idx) => (
                    <li key={idx}>{err.message}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Form Body */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Student ID */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Student ID <span className="text-rose-400">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    name="id"
                    disabled={isEditing}
                    value={formData.id}
                    onChange={handleChange}
                    placeholder="e.g. STD-1001"
                    className={`flex-1 px-3 py-2 bg-slate-800 border ${
                      getFieldError('id') ? 'border-rose-500' : 'border-slate-700'
                    } rounded-xl text-xs font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed`}
                  />
                  {!isEditing && (
                    <button
                      type="button"
                      onClick={handleGenerateId}
                      className="px-2.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl text-xs flex items-center gap-1 shrink-0 transition-colors"
                      title="Auto-generate next available Student ID"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Auto ID</span>
                    </button>
                  )}
                </div>
                {getFieldError('id') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('id')}</p>
                )}
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="e.g. Eleanor Vance"
                  className={`w-full px-3 py-2 bg-slate-800 border ${
                    getFieldError('fullName') ? 'border-rose-500' : 'border-slate-700'
                  } rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                {getFieldError('fullName') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('fullName')}</p>
                )}
              </div>

              {/* Gender */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Gender <span className="text-rose-400">*</span>
                </label>
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Date of Birth */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Date of Birth <span className="text-rose-400">*</span>
                </label>
                <input
                  type="date"
                  name="dob"
                  value={formData.dob}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 bg-slate-800 border ${
                    getFieldError('dob') ? 'border-rose-500' : 'border-slate-700'
                  } rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                {getFieldError('dob') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('dob')}</p>
                )}
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Email Address <span className="text-rose-400">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="e.g. eleanor.vance@university.edu"
                  className={`w-full px-3 py-2 bg-slate-800 border ${
                    getFieldError('email') ? 'border-rose-500' : 'border-slate-700'
                  } rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                {getFieldError('email') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('email')}</p>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Phone Number <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="e.g. +1 (555) 234-5678"
                  className={`w-full px-3 py-2 bg-slate-800 border ${
                    getFieldError('phone') ? 'border-rose-500' : 'border-slate-700'
                  } rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                {getFieldError('phone') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('phone')}</p>
                )}
              </div>

              {/* GPA (FR-06: 0.0 - 4.0) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  GPA (0.00 - 4.00) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="4"
                  name="gpa"
                  value={formData.gpa}
                  onChange={handleChange}
                  placeholder="e.g. 3.75"
                  className={`w-full px-3 py-2 bg-slate-800 border ${
                    getFieldError('gpa') ? 'border-rose-500' : 'border-slate-700'
                  } rounded-xl text-xs font-bold text-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                {getFieldError('gpa') && (
                  <p className="text-[11px] text-rose-400 mt-1">{getFieldError('gpa')}</p>
                )}
              </div>

              {/* Department */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Academic Department
                </label>
                <select
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Student Status
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="Graduated">Graduated</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              {/* Enrollment Year */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Enrollment Year
                </label>
                <input
                  type="number"
                  name="enrollmentYear"
                  value={formData.enrollmentYear}
                  onChange={handleChange}
                  min="2010"
                  max="2030"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

            </div>

            {/* Footer buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800 mt-6">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-600/30 flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>{isEditing ? 'Save Changes' : 'Create Student'}</span>
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
