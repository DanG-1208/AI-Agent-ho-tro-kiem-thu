/**
 * Student Management System Data Models & Types
 */

export type Gender = 'Male' | 'Female' | 'Other';

export type StudentStatus = 'Active' | 'Inactive' | 'Graduated' | 'On Leave';

export interface Student {
  id: string; // Unique Student ID (e.g. STD-1001)
  fullName: string;
  gender: Gender;
  dob: string; // YYYY-MM-DD
  email: string;
  phone: string;
  gpa: number; // 0.0 - 4.0
  department: string; // e.g. Computer Science, Business Administration, etc.
  status: StudentStatus;
  enrollmentYear: number;
  avatarUrl?: string;
  createdAt: string; // ISO string
  updatedAt?: string;
}

export interface StudentFormData {
  id: string;
  fullName: string;
  gender: Gender;
  dob: string;
  email: string;
  phone: string;
  gpa: string; // Managed as string in forms for smooth typing
  department: string;
  status: StudentStatus;
  enrollmentYear: string;
}

export interface ValidationError {
  field: keyof StudentFormData;
  message: string;
}

export interface StudentFilterState {
  searchQuery: string; // Search by ID or Name
  department: string;
  gender: string;
  status: string;
  minGpa: number;
  maxGpa: number;
  sortBy: keyof Student;
  sortOrder: 'asc' | 'desc';
}

export type ExportFormat = 'xlsx' | 'csv';

export interface ExportOptions {
  format: ExportFormat;
  scope: 'all' | 'filtered' | 'selected';
  includeFields: (keyof Student)[];
  fileName: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}
