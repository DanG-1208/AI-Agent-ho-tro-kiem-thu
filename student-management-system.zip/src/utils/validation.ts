import { Student, StudentFormData, ValidationError } from '../types/student';

/**
 * Validates student form data for FR-06
 */
export function validateStudentForm(
  formData: StudentFormData,
  existingStudents: Student[],
  isEditing: boolean = false
): ValidationError[] {
  const errors: ValidationError[] = [];

  // FR-06: Student ID cannot be empty
  const trimmedId = formData.id.trim();
  if (!trimmedId) {
    errors.push({ field: 'id', message: 'Student ID cannot be empty.' });
  } else if (!/^[A-Za-z0-9_-]{2,20}$/.test(trimmedId)) {
    errors.push({
      field: 'id',
      message: 'Student ID must be 2-20 alphanumeric characters (hyphens & underscores allowed).'
    });
  } else if (!isEditing) {
    // Check uniqueness when adding new student
    const isDuplicate = existingStudents.some(
      (s) => s.id.toLowerCase() === trimmedId.toLowerCase()
    );
    if (isDuplicate) {
      errors.push({
        field: 'id',
        message: `Student ID "${trimmedId}" already exists in the system.`
      });
    }
  }

  // Full Name validation
  const trimmedName = formData.fullName.trim();
  if (!trimmedName) {
    errors.push({ field: 'fullName', message: 'Full Name cannot be empty.' });
  } else if (trimmedName.length < 2) {
    errors.push({ field: 'fullName', message: 'Full Name must be at least 2 characters long.' });
  } else if (!/^[a-zA-Z\s\.\-']+$/.test(trimmedName)) {
    errors.push({ field: 'fullName', message: 'Full Name should only contain letters, spaces, and standard punctuation.' });
  }

  // FR-06: Email must follow a valid format
  const trimmedEmail = formData.email.trim();
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!trimmedEmail) {
    errors.push({ field: 'email', message: 'Email address cannot be empty.' });
  } else if (!emailRegex.test(trimmedEmail)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address (e.g. student@university.edu).'
    });
  }

  // Phone validation
  const trimmedPhone = formData.phone.trim();
  if (!trimmedPhone) {
    errors.push({ field: 'phone', message: 'Phone number cannot be empty.' });
  } else if (!/^[+]*[(]?[0-9]{1,4}[)]?[-\s./0-9]{6,15}$/.test(trimmedPhone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number (e.g., +1 (555) 234-5678 or 0987654321).'
    });
  }

  // FR-06: GPA must be between 0 and 4
  const gpaNum = parseFloat(formData.gpa);
  if (formData.gpa === '' || isNaN(gpaNum)) {
    errors.push({ field: 'gpa', message: 'GPA must be a valid number.' });
  } else if (gpaNum < 0.0 || gpaNum > 4.0) {
    errors.push({
      field: 'gpa',
      message: 'GPA must be between 0.00 and 4.00.'
    });
  }

  // Date of Birth validation
  if (!formData.dob) {
    errors.push({ field: 'dob', message: 'Date of Birth is required.' });
  } else {
    const dobDate = new Date(formData.dob);
    const today = new Date();
    if (isNaN(dobDate.getTime())) {
      errors.push({ field: 'dob', message: 'Invalid Date of Birth.' });
    } else if (dobDate >= today) {
      errors.push({ field: 'dob', message: 'Date of Birth must be in the past.' });
    }
  }

  return errors;
}

/**
 * Generates a suggested new unique Student ID like "STD-1013"
 */
export function generateNextStudentId(existingStudents: Student[]): string {
  let maxNum = 1000;
  for (const s of existingStudents) {
    const match = s.id.match(/\d+/);
    if (match) {
      const num = parseInt(match[0], 10);
      if (num > maxNum) {
        maxNum = num;
      }
    }
  }
  return `STD-${maxNum + 1}`;
}
