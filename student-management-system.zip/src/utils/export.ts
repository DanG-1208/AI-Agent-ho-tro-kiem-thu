import * as XLSX from 'xlsx';
import { Student, ExportOptions } from '../types/student';

/**
 * Utility to export student records to Excel (.xlsx) or CSV (.csv) for FR-07
 */
export function exportStudentData(students: Student[], options: ExportOptions): void {
  if (students.length === 0) {
    throw new Error('No student data available to export.');
  }

  // Map student objects to raw plain object rows with nice column headers
  const exportData = students.map((s) => {
    const row: Record<string, string | number> = {};

    if (options.includeFields.includes('id')) row['Student ID'] = s.id;
    if (options.includeFields.includes('fullName')) row['Full Name'] = s.fullName;
    if (options.includeFields.includes('gender')) row['Gender'] = s.gender;
    if (options.includeFields.includes('dob')) row['Date of Birth'] = s.dob;
    if (options.includeFields.includes('email')) row['Email'] = s.email;
    if (options.includeFields.includes('phone')) row['Phone Number'] = s.phone;
    if (options.includeFields.includes('gpa')) row['GPA'] = s.gpa;
    if (options.includeFields.includes('department')) row['Department'] = s.department;
    if (options.includeFields.includes('status')) row['Status'] = s.status;
    if (options.includeFields.includes('enrollmentYear')) row['Enrollment Year'] = s.enrollmentYear;

    return row;
  });

  const baseFileName = options.fileName.trim() || 'student_records';

  if (options.format === 'xlsx') {
    // Generate Excel Workbook
    const worksheet = XLSX.utils.json_to_sheet(exportData);

    // Calculate dynamic column widths
    const columnKeys = Object.keys(exportData[0] || {});
    const colWidths = columnKeys.map((key) => {
      let maxLen = key.length;
      exportData.forEach((row) => {
        const val = String(row[key] || '');
        if (val.length > maxLen) maxLen = val.length;
      });
      return { wch: Math.min(Math.max(maxLen + 3, 12), 40) };
    });
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Students');

    // Trigger download
    XLSX.writeFile(workbook, `${baseFileName}.xlsx`);
  } else if (options.format === 'csv') {
    // Generate CSV string with UTF-8 BOM for perfect Excel CSV opening
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const csvContent = XLSX.utils.sheet_to_csv(worksheet);

    const blob = new Blob(['\uFEFF' + csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${baseFileName}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
