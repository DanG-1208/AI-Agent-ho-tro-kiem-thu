import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Student,
  StudentFilterState,
  StudentFormData,
  ToastMessage,
  ExportOptions
} from '../types/student';
import { INITIAL_STUDENTS } from '../data/mockStudents';
import { validateStudentForm } from '../utils/validation';
import { exportStudentData } from '../utils/export';

const STORAGE_KEY = 'sms_students_data_v1';

interface StudentContextType {
  students: Student[];
  filteredStudents: Student[];
  filters: StudentFilterState;
  setFilters: React.Dispatch<React.SetStateAction<StudentFilterState>>;
  selectedStudentIds: string[];
  setSelectedStudentIds: React.Dispatch<React.SetStateAction<string[]>>;
  
  // Modals & Active State
  isAddModalOpen: boolean;
  setIsAddModalOpen: (open: boolean) => void;
  editingStudent: Student | null;
  setEditingStudent: (student: Student | null) => void;
  viewingStudent: Student | null;
  setViewingStudent: (student: Student | null) => void;
  deletingStudent: Student | null;
  setDeletingStudent: (student: Student | null) => void;
  isBulkDeleteOpen: boolean;
  setIsBulkDeleteOpen: (open: boolean) => void;
  isExportModalOpen: boolean;
  setIsExportModalOpen: (open: boolean) => void;
  isDocModalOpen: boolean;
  setIsDocModalOpen: (open: boolean) => void;

  // Actions
  addStudent: (formData: StudentFormData) => { success: boolean; errors?: any[] };
  updateStudent: (formData: StudentFormData) => { success: boolean; errors?: any[] };
  deleteStudent: (id: string) => void;
  deleteBulkStudents: (ids: string[]) => void;
  resetToSampleData: () => void;
  handleExport: (options: ExportOptions) => void;
  
  // Selection helpers
  toggleSelectStudent: (id: string) => void;
  toggleSelectAll: () => void;
  clearSelection: () => void;

  // Search & Filter Quick Actions
  clearFilters: () => void;

  // Toast
  toasts: ToastMessage[];
  addToast: (type: ToastMessage['type'], title: string, message: string) => void;
  removeToast: (id: string) => void;

  // Statistics
  stats: {
    total: number;
    activeCount: number;
    averageGpa: number;
    honorStudents: number; // GPA >= 3.5
    genderCount: { Male: number; Female: number; Other: number };
    gpaRanges: { excelente: number; bueno: number; promedio: number; bajo: number };
  };
}

const StudentContext = createContext<StudentContextType | undefined>(undefined);

export const StudentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load students from localStorage or fallback to INITIAL_STUDENTS
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load students from localStorage', e);
    }
    return INITIAL_STUDENTS;
  });

  // Save to localStorage when students change (NFR-03 Reliability)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    } catch (e) {
      console.error('Failed to save students to localStorage', e);
    }
  }, [students]);

  // Filters State
  const [filters, setFilters] = useState<StudentFilterState>({
    searchQuery: '',
    department: '',
    gender: '',
    status: '',
    minGpa: 0,
    maxGpa: 4,
    sortBy: 'id',
    sortOrder: 'asc'
  });

  // Selection
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null);
  const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: ToastMessage['type'], title: string, message: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, type, title, message }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Filtered & Sorted list calculation
  const filteredStudents = useMemo(() => {
    return students
      .filter((student) => {
        // Search by ID or Full Name or Email (FR-04)
        if (filters.searchQuery.trim()) {
          const q = filters.searchQuery.toLowerCase().trim();
          const matchId = student.id.toLowerCase().includes(q);
          const matchName = student.fullName.toLowerCase().includes(q);
          const matchEmail = student.email.toLowerCase().includes(q);
          if (!matchId && !matchName && !matchEmail) return false;
        }

        // Department
        if (filters.department && student.department !== filters.department) {
          return false;
        }

        // Gender
        if (filters.gender && student.gender !== filters.gender) {
          return false;
        }

        // Status
        if (filters.status && student.status !== filters.status) {
          return false;
        }

        // GPA Range
        if (student.gpa < filters.minGpa || student.gpa > filters.maxGpa) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        const key = filters.sortBy;
        let valA = a[key];
        let valB = b[key];

        if (typeof valA === 'string') {
          valA = (valA as string).toLowerCase();
          valB = (valB as string).toLowerCase();
        }

        if (valA! < valB!) return filters.sortOrder === 'asc' ? -1 : 1;
        if (valA! > valB!) return filters.sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [students, filters]);

  // Statistics calculation
  const stats = useMemo(() => {
    const total = students.length;
    const activeCount = students.filter((s) => s.status === 'Active').length;
    const sumGpa = students.reduce((acc, s) => acc + s.gpa, 0);
    const averageGpa = total > 0 ? parseFloat((sumGpa / total).toFixed(2)) : 0;
    const honorStudents = students.filter((s) => s.gpa >= 3.5).length;

    const genderCount = {
      Male: students.filter((s) => s.gender === 'Male').length,
      Female: students.filter((s) => s.gender === 'Female').length,
      Other: students.filter((s) => s.gender === 'Other').length
    };

    const gpaRanges = {
      excelente: students.filter((s) => s.gpa >= 3.5).length, // 3.5 - 4.0
      bueno: students.filter((s) => s.gpa >= 3.0 && s.gpa < 3.5).length, // 3.0 - 3.49
      promedio: students.filter((s) => s.gpa >= 2.5 && s.gpa < 3.0).length, // 2.5 - 2.99
      bajo: students.filter((s) => s.gpa < 2.5).length // < 2.5
    };

    return {
      total,
      activeCount,
      averageGpa,
      honorStudents,
      genderCount,
      gpaRanges
    };
  }, [students]);

  // Actions
  const addStudent = (formData: StudentFormData) => {
    const errors = validateStudentForm(formData, students, false);
    if (errors.length > 0) {
      return { success: false, errors };
    }

    const newStudent: Student = {
      id: formData.id.trim(),
      fullName: formData.fullName.trim(),
      gender: formData.gender,
      dob: formData.dob,
      email: formData.email.trim(),
      phone: formData.phone.trim(),
      gpa: parseFloat(formData.gpa),
      department: formData.department || 'General Studies',
      status: formData.status,
      enrollmentYear: parseInt(formData.enrollmentYear, 10) || new Date().getFullYear(),
      createdAt: new Date().toISOString()
    };

    setStudents((prev) => [newStudent, ...prev]);
    addToast('success', 'Student Added', `Student ${newStudent.fullName} (${newStudent.id}) was created successfully.`);
    return { success: true };
  };

  const updateStudent = (formData: StudentFormData) => {
    const errors = validateStudentForm(formData, students, true);
    if (errors.length > 0) {
      return { success: false, errors };
    }

    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === formData.id) {
          return {
            ...s,
            fullName: formData.fullName.trim(),
            gender: formData.gender,
            dob: formData.dob,
            email: formData.email.trim(),
            phone: formData.phone.trim(),
            gpa: parseFloat(formData.gpa),
            department: formData.department,
            status: formData.status,
            enrollmentYear: parseInt(formData.enrollmentYear, 10) || s.enrollmentYear,
            updatedAt: new Date().toISOString()
          };
        }
        return s;
      })
    );

    addToast('success', 'Student Updated', `Student details for ${formData.fullName} were updated successfully.`);
    return { success: true };
  };

  const deleteStudent = (id: string) => {
    const target = students.find((s) => s.id === id);
    setStudents((prev) => prev.filter((s) => s.id !== id));
    setSelectedStudentIds((prev) => prev.filter((sId) => sId !== id));
    addToast(
      'info',
      'Student Removed',
      `Student ${target ? target.fullName : id} has been permanently deleted.`
    );
  };

  const deleteBulkStudents = (ids: string[]) => {
    setStudents((prev) => prev.filter((s) => !ids.includes(s.id)));
    setSelectedStudentIds([]);
    addToast('info', 'Batch Deletion', `${ids.length} student records removed successfully.`);
  };

  const resetToSampleData = () => {
    setStudents(INITIAL_STUDENTS);
    setSelectedStudentIds([]);
    addToast('success', 'Database Reset', 'Reset to initial sample student dataset (12 records).');
  };

  const handleExport = (options: ExportOptions) => {
    let sourceData: Student[] = [];
    if (options.scope === 'all') {
      sourceData = students;
    } else if (options.scope === 'filtered') {
      sourceData = filteredStudents;
    } else if (options.scope === 'selected') {
      sourceData = students.filter((s) => selectedStudentIds.includes(s.id));
    }

    if (sourceData.length === 0) {
      addToast('warning', 'Export Empty', 'No records match the current export scope.');
      return;
    }

    try {
      exportStudentData(sourceData, options);
      addToast(
        'success',
        'Export Complete',
        `Successfully downloaded ${sourceData.length} student record(s) in .${options.format} format.`
      );
    } catch (e: any) {
      addToast('error', 'Export Failed', e.message || 'Could not export file.');
    }
  };

  // Selection
  const toggleSelectStudent = (id: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(id) ? prev.filter((sId) => sId !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedStudentIds.length === filteredStudents.length && filteredStudents.length > 0) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(filteredStudents.map((s) => s.id));
    }
  };

  const clearSelection = () => {
    setSelectedStudentIds([]);
  };

  const clearFilters = () => {
    setFilters({
      searchQuery: '',
      department: '',
      gender: '',
      status: '',
      minGpa: 0,
      maxGpa: 4,
      sortBy: 'id',
      sortOrder: 'asc'
    });
  };

  return (
    <StudentContext.Provider
      value={{
        students,
        filteredStudents,
        filters,
        setFilters,
        selectedStudentIds,
        setSelectedStudentIds,
        isAddModalOpen,
        setIsAddModalOpen,
        editingStudent,
        setEditingStudent,
        viewingStudent,
        setViewingStudent,
        deletingStudent,
        setDeletingStudent,
        isBulkDeleteOpen,
        setIsBulkDeleteOpen,
        isExportModalOpen,
        setIsExportModalOpen,
        isDocModalOpen,
        setIsDocModalOpen,
        addStudent,
        updateStudent,
        deleteStudent,
        deleteBulkStudents,
        resetToSampleData,
        handleExport,
        toggleSelectStudent,
        toggleSelectAll,
        clearSelection,
        clearFilters,
        toasts,
        addToast,
        removeToast,
        stats
      }}
    >
      {children}
    </StudentContext.Provider>
  );
};

export const useStudents = () => {
  const context = useContext(StudentContext);
  if (!context) {
    throw new Error('useStudents must be used within a StudentProvider');
  }
  return context;
};
