/**
 * Student Management System Main Application Component
 */
import React from 'react';
import { StudentProvider } from './context/StudentContext';
import { Header } from './components/Header';
import { StatsOverview } from './components/StatsOverview';
import { StudentTable } from './components/StudentTable';
import { StudentFormModal } from './components/StudentFormModal';
import { StudentDetailModal } from './components/StudentDetailModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ExportModal } from './components/ExportModal';
import { RequirementDocView } from './components/RequirementDocView';
import { ToastContainer } from './components/Toast';

export default function App() {
  return (
    <StudentProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
        
        {/* Main Sticky Header */}
        <Header />

        {/* Main Content Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          
          {/* Analytics & Key Metrics Section */}
          <StatsOverview />

          {/* Core Table View (FR-04, FR-05) */}
          <StudentTable />

        </main>

        {/* Footer */}
        <footer className="border-t border-slate-900 bg-slate-950/80 py-4 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>© {new Date().getFullYear()} Student Management System • Business Analyst SRS Compliance</p>
            <p className="text-[11px] text-slate-600">
              Built with React, TypeScript, Tailwind CSS & SheetJS (xlsx)
            </p>
          </div>
        </footer>

        {/* Modals & Overlay Workflows */}
        <StudentFormModal />
        <StudentDetailModal />
        <DeleteConfirmModal />
        <ExportModal />
        <RequirementDocView />

        {/* Global Toast Notifications Container */}
        <ToastContainer />

      </div>
    </StudentProvider>
  );
}
